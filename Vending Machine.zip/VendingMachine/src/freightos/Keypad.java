package freightos;

import java.util.ArrayList;
import java.util.Scanner;


public class Keypad {
    public static int readItemId(){
        Scanner scanner = new Scanner(System.in);
	int id = scanner.nextInt();
        return id;
    }
    public static ArrayList<Money> readEnteredMoney(){
        String input;
        Scanner scanner = new Scanner(System.in);
        System.out.println("*      Please insert money :)       *");
        System.out.println("*      You can pay using --->       *");
        System.out.println("Coins(10c,20c,50c,1$),Notes(20$,50$),BankCard");
        System.out.println("Please enter values separeted by white spaces");
        input = scanner.nextLine();
        
        return Money.extarctValueFromString(input);
    }
    
}