package freightos;

public enum Item {

    ROW_11(1,10),ROW_12(2,10),ROW_13(3,30),ROW_14(4,10),ROW_15(5,10),
    
    ROW_21(6,10),ROW_22(7,10),ROW_23(8,10),ROW_24(9,10),ROW_25(10,10),
    
    ROW_31(11,10),ROW_32(12,20),ROW_33(13,10),ROW_34(14,10),ROW_35(15,10),
    
    ROW_41(16,90),ROW_42(17,10),ROW_43(18,10),ROW_44(19,10),ROW_45(20,40),
    
    ROW_51(21,10),ROW_52(22,10),ROW_53(23,50),ROW_54(24,10),ROW_55(25,10);
	
    private int id;
    
    private int price;

    private Item(int id, int price) {
        this.id = id;
        this.price = price;
    }

    public int getName() {
        return id;
    }

    public long getPrice() {
        return price;
    }
    public static Item getItem(int id){
        for(Item item : Item.values()){
            if(item.id == id){
                return item;
            }
        }
        return null;
    }
}