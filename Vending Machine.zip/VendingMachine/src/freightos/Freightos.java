package freightos;
import java.util.ArrayList;


public class Freightos {

    
    public static void main(String[] args) {
        VendingMachine freightosVM = new SnackVendingMachine();
        freightosVM.displayProducts();
        while (freightosVM.itemFound()) {
            try {
                int id = Keypad.readItemId();
                freightosVM.selectItemAndGetPrice(id);
            } catch (SoldOutException soex) {
                System.out.println(soex.getMessage());
            }
        }

        while (freightosVM.fullPaid()) {
            try {
                ArrayList<Money> entered = Keypad.readEnteredMoney();
                for (Money money : entered) {
                    freightosVM.insertMoney(money);
                }
                freightosVM.collectItemAndChange();
            } catch (NoSufficientChangeException nscex) {
                System.out.println(nscex.getMessage());
            } catch (NotFullPaidException nfpex) {
                System.out.println(nfpex.getMessage());
            }
        }

    }

}