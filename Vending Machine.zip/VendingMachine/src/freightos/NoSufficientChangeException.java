package freightos;

public class NoSufficientChangeException extends RuntimeException {

    private String message;

    public NoSufficientChangeException(String string) {
        this.message = string;
    }

    @Override
    public String getMessage() {
        return message;
    }
}